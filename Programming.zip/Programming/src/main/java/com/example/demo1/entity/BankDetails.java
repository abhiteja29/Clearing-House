package com.example.demo1.entity;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByPosition;

public class BankDetails {
	

	 @CsvBindByName(column = "ID")
	 private String ID;
	
	 @CsvBindByName(column = "Bank Name")
	 private String Bank_Name;
	 
	 @CsvBindByName(column = "Type")
	 private String Type;
	 
	 @CsvBindByName(column = "City")
	 private String City;
	 
	 @CsvBindByName(column = "State")
	 private String State;
	
	 public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	@CsvBindByName(column = "Zip code")
	 private String Zip_code;
	 
	 
	 
	 @Override
	public String toString() {
		return "BankDetails [ID=" + ID + ", Bank_Name=" + Bank_Name + ", Type=" + Type + ", City=" + City
				+ ", Zip_code=" + Zip_code + "]";
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getBank_Name() {
		return Bank_Name;
	}

	public void setBank_Name(String bank_Name) {
		Bank_Name = bank_Name;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getZip_code() {
		return Zip_code;
	}

	public void setZip_code(String zip_code) {
		Zip_code = zip_code;
	}

	

}
