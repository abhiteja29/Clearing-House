package com.example.demo1;

import com.example.demo1.entity.BankDetails;
import com.opencsv.bean.CsvToBeanBuilder;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(Demo1Application.class, args);

		String fileName = "C:\\Users\\abhit\\Desktop\\Programming\\src\\ProgrammingAssignment.csv";

		List<BankDetails> beans = new CsvToBeanBuilder(new FileReader(fileName)).withType(BankDetails.class).build().parse();

		beans.forEach(System.out::println);

		searchString(beans);

	}

	private static void searchString(List<BankDetails> beans) {
		System.out.println(
				"Please choose search element \n 1) ZIP COde \n 2) State \n 3) Type  \n 4) City  \n 5) Bank Name \n 6) City and State");
		Scanner myObj = new Scanner(System.in);
		int selection;
		selection = myObj.nextInt();

		switch (selection) {

		case 1:
			Scanner myObj1 = new Scanner(System.in);
			String zipcode;
			System.out.println("Enter Zip code");
			zipcode = myObj1.nextLine();
			List<BankDetails> temp1 = beans.stream().filter(t -> t.getZip_code().equalsIgnoreCase(zipcode))
					.collect(Collectors.toList());
			if (temp1.size() > 0)
				System.out.println(temp1 + "list of bank details");
			else
				System.out.println("No details found");
			break;

		case 2:
			Scanner myObj2 = new Scanner(System.in);
			String state;
			System.out.println("Enter state");
			state = myObj2.nextLine();
			List<BankDetails> temp2 = beans.stream().filter(t -> t.getState().equalsIgnoreCase(state))
					.collect(Collectors.toList());
			if (temp2.size() > 0)
				System.out.println(temp2 + "list of bank details");
			else
				System.out.println("No details found");
			break;
		case 3:

			Scanner myObj3 = new Scanner(System.in);
			String type;
			System.out.println("Enter type");
			type = myObj3.nextLine();
			List<BankDetails> temp3 = beans.stream().filter(t -> t.getType().equalsIgnoreCase(type))
					.collect(Collectors.toList());
			if (temp3.size() > 0)
				System.out.println(temp3 + "list of bank details");
			else
				System.out.println("No details found");
			break;
		case 4:
			Scanner myObj4 = new Scanner(System.in);
			String city;
			System.out.println("Enter City");
			city = myObj4.nextLine();
			List<BankDetails> temp4 = beans.stream().filter(t -> t.getCity().equalsIgnoreCase(city))
					.collect(Collectors.toList());
			if (temp4.size() > 0)
				System.out.println(temp4 + "list of bank details");
			else
				System.out.println("No details found");
			break;

		case 5:
			Scanner myObj5 = new Scanner(System.in);
			String bankName;
			System.out.println("Enter Bankname");
			bankName = myObj5.nextLine();
			List<BankDetails> temp = beans.stream().filter(t -> t.getBank_Name().equalsIgnoreCase(bankName))
					.collect(Collectors.toList());
			if (temp.size() > 0)
				System.out.println(temp + "list of bank details");
			else
				System.out.println("No details found");
			break;
		case 6:
			Scanner myObj6 = new Scanner(System.in);
			String city1;
			String state1;

			System.out.println("Enter City and state");
			city1 = myObj6.nextLine();
			state1 = myObj6.nextLine();
			List<BankDetails> temp6 = beans.stream()
					.filter(t -> t.getCity().equalsIgnoreCase(city1) && t.getState().equalsIgnoreCase(state1))
					.collect(Collectors.toList());
			if (temp6.size() > 0)
				System.out.println(temp6 + "list of bank details");
			else
				System.out.println("No details found");
			break;

		}
		System.out.println("Do you want to coninute Please press Y or N");
		Scanner myObj7 = new Scanner(System.in);
		String exit ;
		exit = myObj7.nextLine();
		System.out.println(exit+"");
		if (exit.equalsIgnoreCase("Y"))
			searchString(beans);
		else
			  System.out.println("Thank you for using our service");
	}

}
